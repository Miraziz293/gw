import React from 'react';
import './Yourself.css';

const ExploreSection = () => {
    return (
        <div className="explore-section">
            <h2 className="explore-title">Prepare Yourself</h2>
            <p className="explore-description">And start exploring with us</p>
            <button className="explore-button">Start Exploring</button> {}
        </div>
    );
};

export default ExploreSection;
