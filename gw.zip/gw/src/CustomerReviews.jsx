import React from "react";
import "./CustomerReviews.css";

const CustomerReviews = () => {
  const reviews = [
    {
      name: "Alpanasap",
      feedback: "Amazing comfortable",
      rating: 5,
      image: "https://thb.tildacdn.one/tild6133-3930-4863-a634-643633303838/-/resize/504x/CoddyCamp_logo.png",
    }
  ]
   

  return (
    <div className="customer-reviews">
      <h2>What do customers say about us?</h2>
      <div className="reviews">
        {reviews.map((review, index) => (
          <div key={index} className="review">
            <img
              src={review.image}
              alt={review.name}
              className="review-image"
            />
            <h3>{review.name}</h3>
            <p>{review.feedback}</p>
            <p>Rating: {review.rating} ⭐</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CustomerReviews;
