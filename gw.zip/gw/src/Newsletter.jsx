import React from "react";
import "./Newsletter.jsx";

const Newsletter = () => {
    const our = [

    ]


    return (
        <div className="subs">
        <h2>Subscribe To Our Newsletter </h2>
        
        </div>
    )
}

export default Newsletter;