import React from "react";
import "./Go.css";

const Go = () => {
  return (
    <>
      <div className="nav">
        <h1>GoTrieop</h1>
        <ul className="links">
          <li>Home</li>
          <li>Services</li>
          <li>Pricing</li>
          <li>Contact</li>
        </ul>
        <div className="login">
          <h1>Sign up</h1>
          <h1>Login</h1>
        </div>
      </div>

  

      <h1> Explore The Natural Be auty Of Halmahera With Us </h1>

      <h4>
        explore the beauty of god's earth in a beautiful forest and have fun{" "}
      </h4>

      <button className="btn-2"> Exsplore Now </button>
    </>
  );
};

const CustomerReviews = () => {
  const reviews = [
    {
      name: "John Doe",
      comment: "Great service! Highly recommend it.",
      rating: 5,
    },
    {
      name: "Jane Smith",
      comment: "Had an amazing experience with GoTrip.",
      rating: 4,
    },
    {
      name: "Alex Johnson",
      comment: "Very user-friendly and efficient.",
      rating: 5,
    },
  ];

  return (
    <div className="customer-reviews">
      <h2>What do customers say about this?</h2>
      <ul>
        {reviews.map((review, index) => (
          <li key={index} className="review">
            <h3>{review.name}</h3>
            <p>{review.comment}</p>
            <span>{"⭐".repeat(review.rating)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Go;
import CustomerReviews from "./path/to/CustomerReviews";
