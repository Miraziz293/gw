import React from "react";
import "./App.css";
import CustomerReviews from "./CustomerReviews";
import ExploreSection from "./Yourself"; // Import
import Newsletter from "./Newsletter.jsx";

function App() {
  return (
    <div className="App">
      <header className="header">
        <a className="logo" href="">GoTrip</a>
        <nav className="navbar">
          <a className="home" href="">Home</a>
          <a className="services" href="">Services</a>
          <a className="pricing" href="">Pricing</a>
          <a className="contact" href="">Contact</a>
        </nav>
        <div className="auth-buttons">
          <button className="sign-up">Sign up</button>
          <button className="login">Login</button>
        </div>
      </header>
      <main className="hero">
        <h1>Explore The Natural Beauty Of Halmahera With Us</h1>
        <p>
          Explore the beauty of God's earth in a beautiful forest and have fun.
        </p>
        <button className="explore-now">Explore Now</button>
      </main>
      <section className="destinations">
        <h2>
          Choice Of <span>Destinations</span>
        </h2>
        <p>
          Explore the beauty of God's earth in a beautiful forest and have fun.
        </p>
        <button className="explore-now">Explore Now</button>

        <div className="slider">
          <button className="prev">&lt;</button>
          <div className="slide">
            <img
              src="https://strafari.com/wp-content/uploads/2023/12/strafari-voyage-travel-ouzbekistan-samarcande-samarkand.jpg?w=1200"
              alt="Destination 1"
            />
          </div>
          <div className="slide">
            <img
              src="https://trvlland.com/wp-content/uploads/2022/09/uzbekistan_tashkent-3.jpg"
              alt="Destination 2"
            />
          </div>
          <div className="slide">
            <img
              src="https://tourcentralasia.com/wp-content/uploads/2023/07/tashkent-city-park-view-from-above-1024x768.jpeg"
              alt="Destination 3"
            />
          </div>
          <button className="next">&gt;</button>
        </div>
      </section>
      <CustomerReviews />
      <ExploreSection /> {}
    </div>
  );
}

export default App;
